import random
import requests
import json
import time
from datetime import datetime
import os,sys
from colorama import init, Fore, Style
def clear():
  os.system("clear")
  print("\033[2J\033[H", end="")
def line():
    width = os.get_terminal_size().columns
    print(Fore.CYAN + "="*width)
def banner():
    width = os.get_terminal_size().columns
    clear()
    print(Fore.CYAN + "="*width)
    print(Fore.GREEN + "TOOL REG AZOTA STUDENT".center(width))
    print(Fore.RED + "By: oibanoi874".center(width))
    print(Fore.CYAN + "="*width)
# -------------------
# Danh sách họ, tên đệm, tên
# -------------------
last_names = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Huỳnh", "Vũ", "Võ", "Đặng", "Bùi"]
middle_names = ["Văn", "Thị", "Quốc", "Ngọc", "Đình", "Bảo", "Minh", "Hữu", "Hoàng", "Thanh"]
first_names = ["An", "Bình", "Chí", "Dũng", "Em", "Huy", "Lan", "Minh", "Thảo", "Trang"]

# -------------------
# Hàm tạo full name ngẫu nhiên
# -------------------
def generate_full_name():
    style = random.randint(1,5)
    if style == 1:
        return f"{random.choice(last_names)} {random.choice(first_names)}"
    elif style == 2:
        return f"{random.choice(last_names)} {random.choice(middle_names)} {random.choice(first_names)}"
    elif style == 3:
        return f"{random.choice(first_names)} {random.choice(last_names)}"
    elif style == 4:
        return f"{random.choice(middle_names)} {random.choice(last_names)}"
    else:
        return f"{random.choice(last_names)} {random.choice(middle_names)} {random.choice(first_names)}{random.choice(middle_names)}"

# -------------------
# Hàm tạo mật khẩu ngẫu nhiên 8 ký tự
# -------------------
def generate_password(length=8):
    chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return ''.join(random.choice(chars) for _ in range(length))

# -------------------
# Nhập số lượng tài khoản muốn tạo
# -------------------
clear()
banner()
num_accounts = int(input(f"{Fore.GREEN}Nhập số lượng tài khoản muốn tạo{Fore.CYAN}:{Fore.BLUE} "))
line()

# -------------------
# Đọc email từ file mail.txt
# -------------------
with open("mail.txt", "r", encoding="utf-8") as f:
    emails = [line.strip() for line in f if line.strip()]

if num_accounts > len(emails):
    raise Exception(Fore.yellow + "Số lượng yêu cầu lớn hơn số email còn lại trong file!")

# -------------------
# Headers API Azota
# -------------------
headers = {
    'authorization': 'Bearer <TOKEN>',  # thêm token hợp lệ
    'content-type': 'application/json'
}

# -------------------
# Mở file JSON để lưu dữ liệu
# -------------------
json_file = "accounts.json"
try:
    with open(json_file, "r", encoding="utf-8") as f:
        saved_accounts = json.load(f)
except (FileNotFoundError, json.JSONDecodeError):
    saved_accounts = []

# -------------------
# Tạo và gửi payload
# -------------------
for _ in range(num_accounts):
    email = random.choice(emails)
    emails.remove(email)  # xóa email đã dùng

    password = generate_password()
    payload = {
        "fullName": generate_full_name(),
        "password": password,
        "tokenCaptcha": "",  # cần token hợp lệ nếu API yêu cầu
        "language": "vi",
        "domain": "",
        "email": email
    }

    try:
        response = requests.post(
            'https://api.azota.vn/api/Auth/RegisterForStudent',
            headers=headers,
            json=payload
        )

        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        res_json = response.json()
        data = res_json.get("data", {})
        
        if res_json.get("success") == 1 and str(res_json.get("message", "")).lower() == "successful":
            account_data = {
                "id": data.get("id"),
                "fullName": data.get("fullName"),
                "email": data.get("email"),
                "password": password,
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
        
            # In ra thông tin
            
            print(f"{Fore.GREEN}Message   {Fore.CYAN}:{Fore.BLUE} ", res_json.get("message"))
            print(f"{Fore.GREEN}ID        {Fore.CYAN}:{Fore.BLUE} ", account_data["id"])
            print(f"{Fore.GREEN}FullName  {Fore.CYAN}:{Fore.BLUE} ", account_data["fullName"])
            print(f"{Fore.GREEN}Email     {Fore.CYAN}:{Fore.BLUE} ", account_data["email"])
            print(f"{Fore.GREEN}Password  {Fore.CYAN}:{Fore.BLUE} ", account_data["password"])
            print(f"{Fore.GREEN}created_at{Fore.CYAN}:{Fore.BLUE} ", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            line()

            # Lưu vào JSON
            saved_accounts.append(account_data)
            with open(json_file, "w", encoding="utf-8") as f:
                json.dump(saved_accounts, f, ensure_ascii=False, indent=4)
        else:
            print(Fore.RED + "Đăng ký thất bại. Tool sẽ dừng!")
            break



    except Exception as e:
        print(f"{Fore.RED}Lỗi nghiêm trọng với email {email}: {e}. Tool sẽ dừng!")
        break

    # Delay 5 giây giữa các request
    time.sleep(5)

# -------------------
# Ghi lại email còn lại vào file
# -------------------
with open("mail.txt", "w", encoding="utf-8") as f:
    for e in emails:
        f.write(e + "\n")
