import requests
import json

hashId = input("nhập mã đề thi: ")
resultId = input("nhập id đề thi(GetTmpUploadObj-resultId): ")
import requests

headers = {
    'authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyODQ5NjkwNyIsImZ1bGxfbmFtZSI6IlRyYW5nIFRy4bqnbiIsInVzZXJfbmFtZSI6IiIsImVtYWlsIjoibC5odC50LmQuei4yLjEuMDlAZ21haWwuY29tIiwicGhvbmUiOiIiLCJhdmF0YXIiOiIiLCJiaXJ0aGRheSI6IiIsImFtb3VudCI6IjAiLCJnZW5kZXIiOiIwIiwiemFsb19pZCI6IiIsInJvbGVzIjoie1wiJGlkXCI6XCIxXCIsXCJQQVJFTlRcIjoxLFwiU1RVREVOVFwiOjF9IiwiY3JlYXRlZF9ieSI6IiIsInBhc3N3b3JkIjoiIiwiYWxsb3dfc2tpcF92ZXJpZnkiOiIyIiwibGFzdF9hY3Rpdml0eSI6IjIwMjUtMDktMDEgMTQ6MjY6MDciLCJsYW5ndWFnZSI6InZpIiwidmlwIjoiW10iLCJyZWxhdGl2ZV92aXAiOiIwIiwibmJmIjoxNzU2NzExNTY3LCJleHAiOjE3ODc4MTU1NjcsImlhdCI6MTc1NjcxMTU2N30.kgOB8ydUi3DEvTqZy-STa3Frh5PCBLQsMd9lB8nKi4s',
}

params = {
    'hashId': hashId,
    'resultId': resultId,
    'shareOfflineHashId': '',
}

response = requests.get('https://api.azota.vn/api/FrontExamResult/GetExamAnswer', params=params, headers=headers)
res_json = response.json()  # gọi method
questions = res_json.get("data", {}).get("questionObjs", [])

for q in questions:
    answer_type = q.get("answerType")
    content = q.get("content")
    answer_result = q.get("answerResult", [])
    
    if answer_result:
        # Tìm nội dung tương ứng với alpha trong answerResult
        answer_contents = []
        for ans_alpha in answer_result:
            for ans in q.get("answers", []):
                if ans.get("alpha") == ans_alpha:
                    answer_contents.append(ans.get("content"))
        answer_contents_str = ', '.join(answer_contents)
    else:
        # Nếu rỗng thì lấy help
        answer_contents_str = q.get("help", "")
    
    print(f"{content} | {answer_contents_str}")
